NinjaTechEnterprises
====================
NinjaTech Enterprises, putting the possible back into impossible.

Here at NinjaTech Enterprises, we have our great minds to work on developing useful parts for your enjoyment!

We would like to introduce to you our line of Atmospheric RCS Units:
The Atmospheric Linear RCS Port
The Atmospheric RCS Thruster Block

Both require Intake Air, which can be gathered using air intakes. No longer do you have to worry about putting monopropellant tanks on your VTOLS.

Our next line of parts is our SAS Units:
The Advanced SAS Module, Size 3

Now you have a SAS module that you can stick on your 3.75m rockets without having to strut everything together (we know you still will).

Our next line of parts is our Utility Parts:
Service Bay (3.75m)

Now you can have a sevice bay on your Size 3 rockets.

Our next line of parts is our Probe Cores:
RC-S01 Remote Guidance Unit

Now that you have a Size 3 SAS unit, now you can also control your rockets with a Size 3 Probe Core.

Uses stock models and textures.  I would like if someone could help me with models and textures.

Requires: ModuleManager
